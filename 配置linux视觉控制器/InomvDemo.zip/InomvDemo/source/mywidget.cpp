#include "mywidget.h"

MyWidget::MyWidget(QWidget *parent)
    : QWidget(parent)  // 调用父类 QWidget 构造函数，并传递 parent
{
    // 构造函数体
    // 可以在这里初始化界面控件、布局、信号槽连接等

    // 示例：设置窗口标题
    this->setWindowTitle("MyWidget Example");

    // 示例：设置默认大小
    this->resize(400, 300);
}
MyWidget::~MyWidget()
{
    // 析构
}
void MyWidget::test()
{

}