#ifndef MYWIDGET_H
#define MYWIDGET_H

#include <QWidget>

class MyWidget : public QWidget
{
    Q_OBJECT   // Qt 宏，支持信号槽机制
public:
    explicit MyWidget(QWidget *parent = nullptr); // 构造函数声明
    ~MyWidget();  // 声明析构函数
    void test();
};

#endif // MYWIDGET_H